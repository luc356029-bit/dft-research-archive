"""Conditional resource arithmetic only; does not run MD or access an HPC."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
source=R/'cost_and_clock_bounds.json';a=json.loads(source.read_text(encoding='utf-8'))
cpu=next(r for r in a['cost_scenarios'] if r['hardware']=='CPU32')
lo=cpu['measured_loop_real_seconds_min']*2
hi=cpu['measured_loop_real_seconds_max']*6
# An illustrative workload, not a statistically sufficient sample count.
prep_ps=2.0; paths=4; completed_paths_per_family=10; total_saved_time_per_path_ps=.2;dt_fs=.5
steps_per_family=round((prep_ps+completed_paths_per_family*total_saved_time_per_path_ps)*1000/dt_fs)
init_count=1+completed_paths_per_family;init_wall_s=898.79
family_wall_h=[(steps_per_family*c+init_count*init_wall_s)/3600 for c in [lo,hi]]
rows=[]
for nodes in [1,2,4]:
 rows.append({'assumed_concurrent_CPU32_nodes':nodes,'concurrent_CPU_cores':nodes*32,'wall_days_without_queue_or_development':[h*paths/nodes/24 for h in family_wall_h],'total_core_hours':[h*paths*32 for h in family_wall_h]})
out={'date':'2026-11-13','type':'Workload-based conditional forecast, not measured MD or guaranteed convergence','assumptions':{'DFT_reference':'same 63-atom cell and numerical accuracy','dt_fs':dt_fs,'hot_SCF_iterations_assumed':[2,6],'hot_seconds_per_step_conditional':[lo,hi],'saddle_sampling_preparation_ps_per_family':prep_ps,'completed_reactive_paths_illustrated_per_family':completed_paths_per_family,'mean_total_backward_plus_forward_recorded_time_ps_per_path_assumed':total_saved_time_per_path_ps,'steps_per_family':steps_per_family,'total_ps_across_four_families':paths*(prep_ps+completed_paths_per_family*total_saved_time_per_path_ps)},'forecasts':rows,'not_included':['queue delay','implementation and version/MD validation','longer thermalization or decorrelation','unsuccessful or censored trajectories','additional recrossing or residence-time statistics','finite-size transfer to Kirsch defect cell'],'warnings':['Ten paths is only an accounting example; no preset convergence claim','2ps does not certify thermalization or independent TS samples','0.2ps is hypothetical trajectory length, not predicted LiSi transition time','4-node availability and current balance are not verified','No new DFT/MD/KMC, training, or scheduler action performed'],'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
(R/'targeted_md_duration_estimate.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False,indent=2))
