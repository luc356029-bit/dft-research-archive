"""Long-time tagged-Li diffusion of the existing reversible one-vacancy KMC.

This is an exact marginalization/evaluation, not a new kinetic model.
Inputs are the same vacancy jumps and rates as the existing sampler.
Q chi = -drift, D = <sum k (g + chi_next-chi_now)^2>/2.
All other Li particles are indistinguishable for a single tagged particle.
"""
import numpy as np
from scipy.sparse import coo_matrix,diags
from scipy.sparse.linalg import splu
from scipy.sparse.csgraph import connected_components

def tracer_diffusion(neighbor,vacancy_jump,rates,cell=None,path_id=None):
    neighbor=np.asarray(neighbor,dtype=int);jump=np.asarray(vacancy_jump,dtype=float);rates=np.asarray(rates,dtype=float)
    n,degree=neighbor.shape
    if rates.shape!=neighbor.shape or jump.shape!=(n,degree,3) or np.any(rates<0) or not np.all(np.isfinite(rates)):
        raise ValueError('Invalid kinetic arrays')
    if np.any(neighbor==np.arange(n)[:,None]):raise ValueError('Vacancy jump aliases to itself')
    scale=float(rates.max())
    if scale<=0:raise ValueError('No positive rates')
    pairs=np.array([(v,t) for v in range(n) for t in range(n) if t!=v]);m=len(pairs)
    index=np.full((n,n),-1,dtype=int);index[pairs[:,0],pairs[:,1]]=np.arange(m)
    vacancy,tag=pairs.T
    destination=neighbor[vacancy];hit=destination==tag[:,None]
    next_tag=np.where(hit,vacancy[:,None],tag[:,None]);target=index[destination,next_tag]
    source=np.broadcast_to(np.arange(m)[:,None],(m,degree))
    g=np.where(hit[:,:,None],-jump[vacancy],0.)
    r=rates[vacancy]/scale
    active=r>0;src=source[active];dst=target[active];g=g[active];r=r[active]
    Q=coo_matrix((r,(src,dst)),shape=(m,m)).tocsr();Q-=diags(np.asarray(Q.sum(axis=1)).ravel());Q.sum_duplicates()
    anti=Q-Q.T;symerr=float(abs(anti.data).max(initial=0))
    if symerr>1e-12:raise ValueError('Non-reversible or nonuniform-equilibrium rates')
    nc,_=connected_components(Q,directed=False)
    if nc!=1:raise ValueError(f'Marked state graph has {nc} disconnected components')
    b=np.zeros((m,3));np.add.at(b,src,r[:,None]*g)
    if abs(b.sum(axis=0)).max()>1e-10:raise ValueError('Nonzero equilibrium drift')
    chi=np.zeros((m,3));chi[1:]=splu((-Q[1:,1:]).tocsc()).solve(b[1:])
    residual=Q@chi+b
    denominator=max(float((abs(Q)@abs(chi)+abs(b)).max()),1e-30)
    relative_residual=float(abs(residual).max()/denominator)
    if relative_residual>1e-9:raise ValueError('Poisson corrector residual too large')
    corrected=g+chi[dst]-chi[src]
    if cell is not None:corrected=corrected@np.asarray(cell,dtype=float)
    tensor=np.einsum('e,ei,ej->ij',r,corrected,corrected)*scale/(2*m)
    transport=r*np.sum(corrected**2,axis=1)
    contributions=None
    if path_id is not None:
        family=np.asarray(path_id)[vacancy][active]
        contributions=np.bincount(family,weights=transport,minlength=int(np.max(path_id))+1)
        contributions/=sum(contributions)
    return {'D_tensor':tensor,'D_scalar':float(np.trace(tensor)/3),'path_lograte_sensitivities':contributions,'states':m,'directed_edges':len(r),'relative_residual':relative_residual,'reversibility_error':symerr,'tensor_eigenvalues':np.linalg.eigvalsh(tensor)}
