from pathlib import Path
import json,csv,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
H=Path(__file__).resolve().parent;a=json.loads((H/'Ea_recomparison_results.json').read_text());b=json.loads((H/'vacancy_and_Moon_attribution.json').read_text())
C=a['cases'];V={r['case']:r for r in b['vacancy_quantities_do_not_replace_Li_tracer_Ea']}
def ea(name):return C[name]['Ea_250_400_fixed_weights']['Ea_eV']
main_delta=ea('Kirsch3')-ea('own3');path03=ea('own4')-ea('own3')
vac_delta=V['Kirsch3']['local_vacancy_Ea300_eV']-V['own3']['local_vacancy_Ea300_eV']
calmax=max(abs(r['difference_in_existing_SE']) for r in a['existing_KMC_calibration'])
rows=[]
for name,c in C.items():
 rows.append({'case':name,'path_set':'00,01,02' if name in ['own3','Kirsch3'] else '00,01,02,03','cv':1/32,'Li_count':31,'common_nu_s':a['nu_assumption_s'],'Li_Ea250_400_fixed_weights_eV':ea(name),'Li_Ea250_400_OLS_eV':c['Ea_250_400_OLS']['Ea_eV'],'Li_Ea300_700_OLS_eV':c['Ea_300_700_OLS']['Ea_eV'],'vacancy_local_Ea300_eV':V.get(name,{}).get('local_vacancy_Ea300_eV'),'source_status':c['source_status']})
with (H/'Ea_same_model_comparison.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
attr=[]
for i in range(3):
 attr.append({'path_id':i,'own_Em_eV':C['own3']['barriers_eV'][i],'Kirsch_Em_eV':C['Kirsch3']['barriers_eV'][i],'Em_difference_meV':1000*(C['Kirsch3']['barriers_eV'][i]-C['own3']['barriers_eV'][i]),'Li_fitted_Ea_Shapley_meV':1000*a['Shapley_Kirsch_minus_own_eV'][i],'vacancy_local_Ea_Shapley_meV':1000*b['vacancy_local300_Kirsch_input_Shapley_eV'][i]})
with (H/'Ea_barrier_attribution.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(attr[0]));w.writeheader();w.writerows(attr)

fig,axs=plt.subplots(1,3,figsize=(14,4),layout='constrained')
colors={'own4':'k','own3':'tab:blue','Kirsch3':'tab:orange','Moon_mapping_A_CANDIDATE':'tab:green'}
labels={'own4':'Project, 4 paths','own3':'Project, 3 paths','Kirsch3':'Kirsch barriers, 3 paths','Moon_mapping_A_CANDIDATE':'Moon A, conditional'}
for n in colors:
 rr=[r for r in C[n]['rows'] if r['T_K'] in [250,300,350,400]]
 axs[0].plot([1000/r['T_K'] for r in rr],np.log([r['DLi_cm2_s'] for r in rr]),'o-',color=colors[n],label=labels[n])
axs[0].set(xlabel='1000/T (K^-1)',ylabel='ln Li tracer D (cm^2/s)',title='Same fixed-vacancy model');axs[0].legend(fontsize=7)
ns=['own3','Kirsch3','own4','Moon_mapping_A_CANDIDATE','Moon_mapping_B_CANDIDATE'];vals=[ea(n) for n in ns]
axs[1].plot(range(5),vals,'ko');axs[1].set(xticks=range(5),xticklabels=['Own3','Kirsch3','Own4','Moon A','Moon B'],ylabel='Fitted Li Ea / eV',title='250-400 K, same fixed weights')
for i,x in enumerate(vals):axs[1].annotate(f'{x:.6f}',(i,x),xytext=(0,7),textcoords='offset points',ha='center',fontsize=7)
axs[1].set_ylim(.246,.273)
axs[1].set_xlim(-.5,4.5)
sh=np.array(a['Shapley_Kirsch_minus_own_eV'])*1000;axs[2].bar(['00','01','02'],sh,color=['tab:blue','tab:orange','tab:green']);axs[2].axhline(0,color='k',linewidth=.8)
axs[2].set_ylim(-15,14)
axs[2].set(xlabel='Replaced Em family',ylabel='Contribution to Ea difference / meV',title=f'Kirsch3 - Own3 = {main_delta*1000:.3f} meV')
for i,x in enumerate(sh):axs[2].annotate(f'{x:+.3f}',(i,x),ha='center',xytext=(0,5 if x>0 else -13),textcoords='offset points',fontsize=8)
for ax in axs:ax.grid(alpha=.2)
fig.savefig(H/'Ea_external_comparison.png',dpi=180);plt.close(fig)

attr_text='\n'.join(f"|{r['path_id']:02d}|{r['Em_difference_meV']:+.3f}|{r['Li_fitted_Ea_Shapley_meV']:+.3f}|{r['vacancy_local_Ea_Shapley_meV']:+.3f}|" for r in attr)
nu_values=[r['Ea_fixed_weights_eV'] for r in a['path_specific_prefactor_hypotheses']]
status={'date':'2026-11-13','status':'SAME_MODEL_EXTERNAL_MICROSCOPIC_Ea_COMPARISON_COMPLETED','Dou_Npath1_Ea_admitted_as_validation':False,'strict_external_input':'Kirsch2025 three mapped NEB profiles','new_macro_Ea_measurement_found':False,'new_results':{'own3_Li_Ea_eV':ea('own3'),'Kirsch3_Li_Ea_eV':ea('Kirsch3'),'Li_difference_meV':main_delta*1000,'own3_vacancy_local300_eV':V['own3']['local_vacancy_Ea300_eV'],'Kirsch3_vacancy_local300_eV':V['Kirsch3']['local_vacancy_Ea300_eV'],'vacancy_difference_meV':vac_delta*1000,'own4_exact_Li_Ea_eV':ea('own4'),'own4_original_KMC_Ea_eV':a['original_KMC_Ea_fixed_weights_eV']},'scope':'Independent barrier input validation under common finite model, not independent macroscopic experiment or full external four-path model','production_files_changed':False,'new_DFT_MD_or_KMC_trajectories':False}
(H/'Ea_validation_status.json').write_text(json.dumps(status,ensure_ascii=False,indent=2))
report=f'''# LiSi Ea重新对照：移除单路径基准，统一模型后验证与归因

2026-11-13（Asia/Shanghai）。本轮按用户要求重新评估Ea，不新增DFT/AIMD、ML训练或超算；也没有新增随机KMC轨迹。所有新代码和结果在独立目录，原生产文件不变。

## 1. 先给结论及纠正

【结论】原复刻论文Dou的Npath=1及0.268 eV**退出Ea验证基准**。Npath=1指所列路径数，不是本项目path01。已有完整网络/多路径证据足以质疑单路径代表总体输运；这不等于已经逐项证明作者某个NEB单步数值或未公开代码错误。此前把0.268列在差异表中仍容易让人误以为它是合格标杆，本轮明确撤销这一用途。

【本轮实际结果】已得到不依赖Dou的、可复现的**独立NEB输入＋同模型Ea对照**。最强来源是Kirsch2025作者公开三条原始能量；它没有独立温度序列Ea，下面的数值是本轮统一模型重算，不能冒称“Kirsch论文报告的Ea”。

|统一后的观测量与路径集合|本项目Em输入|Kirsch独立Em输入|外部输入−本项目|
|---|---:|---:|---:|
|三共同路径；300 K空位网络局部斜率/eV|{V['own3']['local_vacancy_Ea300_eV']:.6f}|{V['Kirsch3']['local_vacancy_Ea300_eV']:.6f}|{vac_delta*1000:+.3f} meV|
|三共同路径；250–400 K Li示踪拟合Ea/eV|{ea('own3'):.6f}|{ea('Kirsch3'):.6f}|{main_delta*1000:+.3f} meV|

【可支持的判断】在固定空位、共同恒定尝试频率的共同网络模型下，**低温有效Ea约0.25 eV获得独立微观势垒数据支持**，不必借用原论文单路径Ea。不能扩大为“真实材料Ea已验证到1 meV”或“本征/宏观Ea实验验证完成”。原始外部DFT缺力/SCF误差界，跨协议及前因子不确定性远未缩小到上述数值差。

## 2. 如何真正统一口径

【已有证据】对象为I4₁/a晶态LiSi；本项目原Em为00/01/02/03={C['own4']['barriers_eV']} eV。Kirsch原始16图像能量用Hartree转eV、两端均值对称化，已完成的几何映射继续使用：6→00、8→01、7→02；本轮从原能量文件再次核对，三Em分别0.220285873、0.284871473、0.252610229 eV。没有按数值接近重新配路径。

【本轮约定】双方都放入同一32个Li宿主位点、一个中性空位、31个Li的有限周期图；共同ν=1e13 s⁻¹是明示假设；Li量为所有Li的长时间示踪MSD/(6×31×t)，标量trace(D)/3；主拟合都是250/300/350/400 K及同一固定权重。空位D和局部斜率单列。对外部Em做的是**同模型重算**，不是把别人D乘浓度因子，亦没有声称其255原子DFT势垒已转换成63原子DFT极限。

【路径集缺口的处理】Kirsch只给三条对应空位路径，缺本项目03。因此主对照双方都去掉03，保持同一图。不能偷偷保留本项目03，再说结果完全来自外部。三路径下两个标记状态图仍连通，扩散张量三本征值均正；不是把不贯通图拿来拟合。

【拟合权重】主表固定使用原Li KMC的边际SE权重，两个模型完全一致，不按参考结果选权重。等权重时Li Ea分别{C['own3']['Ea_250_400_OLS']['Ea_eV']:.6f}/{C['Kirsch3']['Ea_250_400_OLS']['Ea_eV']:.6f} eV，差约{1000*(C['Kirsch3']['Ea_250_400_OLS']['Ea_eV']-C['own3']['Ea_250_400_OLS']['Ea_eV']):.3f} meV，核心判断不依赖这一权重选择。

【方法与数值可信度】直接求现有单空位KMC的长期标记Li边际过程，不改变跳跃机制或速率式。Poisson正确子精确计入已有的排斥交换/回跳相关性；整数周期像规范消除有界胞内位移的舍入伪扩散。四个一维环解析/规范/速率尺度校准通过；与原四温点Li KMC的D差均≤{calmax:.3f}个既有SE。局部斜率的输运响应公式与直接温度差分误差<1e-7 eV。主比较CPU计算约{a['runtime_seconds']:.2f}秒（另有辅助求值），不是新建复杂动力学修正模型或重验全部流程。

## 3. 与当前完整四路径结果的关系

【已有证据】此前300 K网络Ea=0.25070397 eV是**空位局部斜率**；Li的250–400 K原KMC拟合Ea=0.251611 eV是另一观测量。本轮始终分别匹配。

【本轮实际结果】完整四路径原模型的精确Li拟合Ea={ea('own4'):.6f} eV，和旧KMC中心值差{1000*(ea('own4')-a['original_KMC_Ea_fixed_weights_eV']):+.3f} meV，处于旧统计误差内。没有覆盖或改写旧原始结果。相同模型的300 K空位局部值仍为{V['own4']['local_vacancy_Ea300_eV']:.8f} eV，与原值相符。

去掉03使Li拟合Ea降低{1000*path03:.3f} meV、空位局部Ea降低{1000*(V['own4']['local_vacancy_Ea300_eV']-V['own3']['local_vacancy_Ea300_eV']):.3f} meV。**不能将完整四路径{ea('own4'):.6f}与外部三路径{ea('Kirsch3'):.6f}仅差{1000*(ea('Kirsch3')-ea('own4')):+.3f} meV当“完美吻合”**：这里03删边的影响正好抵消了一部分外部势垒变化。

若作为明确的混合输入桥接，将本项目03加回Kirsch三路径，则Li Ea={ea('Kirsch3_plus_own03_BRIDGE'):.6f} eV；这不是纯外部基准。假设未知外部03为0.40/0.42766/0.4658/0.50 eV时，对应Li Ea约0.254030/0.252528/0.251673/0.251406 eV。**这些只是缺路径敏感性场景，不是已知03的物理误差界**。

## 4. Kirsch对照为什么Ea接近：已能定量解释

【本轮实际结果】固定三路径图，穷举三Em替换的8种组合，对六种替换顺序取平均分摊有限差异（Shapley）。因此保留非线性，不把单路径变化简单相加。该分摊是一种明确约定，不是声称有唯一微观因果分解。

|输入路径|Kirsch Em−本项目/meV|对Li拟合Ea的分摊/meV|对300 K空位局部Ea的分摊/meV|
|---|---:|---:|---:|
{attr_text}
|合计|—|{main_delta*1000:+.3f}|{vac_delta*1000:+.3f}|

【模型内归因成立】Kirsch的00势垒更低，使有效Ea下降；01和02的势垒更高，部分抵消。Ea接近不证明各条Em接近，也不证明主控路径相同。300 K时Li D对各通道ln速率的响应权重，本项目三路径为00/01/02≈72.66%/15.36%/11.98%，Kirsch输入变成24.18%/20.20%/55.62%。控制权由00转向02，最终仍给约0.25 eV。

这些权重是∂lnD/∂lnk，不是事件次数占比；在共同常量前因子和可逆图下，局部Ea=Σᵢ(∂lnD/∂lnkᵢ)Emᵢ。它清楚区分路径障碍、输运相关性与网络Ea。

## 5. Moon作为第二组交叉对照：不挑只接近的数据

【已有证据】出版社官方Fig4的四近邻Em：green0.2725、red0.2519、brown0.2348、blue0.4658 eV。依据既有结构描述，把最短green暂对应00、较长blue暂对应03；红/棕对01/02的两种候选都保留。这里仍缺严格端点坐标映射，故等级低于Kirsch，不声称完成期刊全部复现。

【本轮实际结果】采用同一有限图/ν/拟合口径，两候选给Li Ea=**{min(ea('Moon_mapping_A_CANDIDATE'),ea('Moon_mapping_B_CANDIDATE')):.6f}–{max(ea('Moon_mapping_A_CANDIDATE'),ea('Moon_mapping_B_CANDIDATE')):.6f} eV**，高于本项目完整四路径约16.91–17.00 meV。两簇内边换色只改变约0.085 meV，不能解释这个17 meV差。

四Em置换的16组合分摊显示：00单独贡献约+17.99～+18.12 meV，其余三类合计约−1.0～−1.2 meV。因此，**在这些映射假设内，Ea差主要来自Moon最短桥接边0.2725比本项目0.253444高19.06 meV**，已定位到具体输入路径；不是拟合噪声或中间两条路径配色问题。

【尚未解释】Moon为LDA/PAW、Li_sv、500eV，本项目为PBE/PAW、520eV；晶胞/缺陷/基组/约束亦未全部统一。不能凭泛函名称把19 meV指定为LDA效应。要唯一分离其物理来源需同协议DFT控制，这超出本轮低成本范围。

【不强行转换】Moon摘要0.306 eV仍不直接准入。即使把本轮共同模型拟合改为300–700 K，两个候选也仅为0.273676–0.273809 eV；它不是同口径复现0.306的证据。逐路径ν、实际缺陷浓度、MSD/拟合输入仍缺。Kumar的0.27同样不由已知常数归一就能准确变成本项目Li示踪斜率。Moon重建约0.268与Dou原0.268数值接近，也不会恢复Dou单路径验证资格。

## 6. 还不能把哪些差异“准确换算”

|问题|本轮处理与状态|
|---|---|
|固定浓度和Li/空位归一|通过共同有限模型重新求值，未靠乘常数处理温变相关性；**共同模型下已对齐**|
|常量共同ν|只改D振幅，不改Ea；没有用D反拟合ν；**假设明确**|
|路径特异ν|Kirsch不提供。只做各三路径相对ν∈{{1,2}}的假设角点，Li Ea范围{min(nu_values):.6f}–{max(nu_values):.6f}eV；**敏感性，不是误差条或测得ν**|
|未知03及更多机制|已剔除双方03作严格主比较，并给桥接敏感性；**完整外部四路径基准仍缺**|
|晶胞/泛函/D3/DFT尺寸|原Em来自不同实际计算协议；数值差保留，不无依据校正；**唯一物理原因未分离**|
|实验Ea、化学扩散、本征浓度|没有找到可无额外未知量转换的目标晶态LiSi宏观Ea；不移用其他硅化锂或非晶QENS；**仍未验证**|
|温区|主表同250–400K。比如本项目四路径改300–700K会变为0.260373eV，故不能拿不同温区的单个Ea硬比；**定义影响可量化**|

【检索边界】本轮新增定向查同相Ea/单空位原始资料及主方程方法，没有重跑失败SI下载或扩材料高召回检索。仍未发现新的可直接准入目标宏观Ea；“新对照”是本轮从独立原始Em严格转换出的数值，不包装为新找到实验值。

【误差边界】Kirsch两端点能量劈裂约0.06–0.09meV，本轮沿用等价位点的两端均值对称化；没有其逐图像力/SCF误差界。因此不能把0.147meV差说成物理精度证书。本轮仍是经典、恒定前因子、瞬时跳跃模型；量子/非谐/热膨胀与温变κ/ν未加入，也未解决前轮800K迁移过程时间问题。

## 7. 最终建议与停止条件

1. 当前Ea验证应改写为：**固定缺陷、指定速率模型的低温Ea≈0.25 eV获得Kirsch独立微观输入的同模型支持；完整本项目Li Ea约0.2513 eV；真实宏观/本征Ea尚未验证。** 不再以Dou的0.268作为准确性依据。
2. 不只保留有利结果：Moon条件重建给约0.2683 eV，差异已主要定位到00输入；协议层归因未完成。两组资料共同说明跨DFT来源可存在十几meV网络Ea差，不能宣称当前已达meV物理准确度。
3. 本轮已用极低计算成本得到可复核的对照与有限差异归因；没有必要为此重跑NEB、AIMD或新增大量KMC。只有要分离19meV的具体DFT成因、验证真实温变前因子/缺陷浓度或完整四路径物理Ea时，才需要新外部数据或较高成本计算；不自动开展。

## 8. 复现和证据

主脚本`recompare_ea.py`与`exact_tracer.py`，补充脚本`supplement_vacancy_and_moon.py`；`test_exact_tracer.py`为解析校准，`kinetic_inputs.json`冻结原模型图和外部Em。`Ea_recomparison_results.json`、`vacancy_and_Moon_attribution.json`包含逐温D/张量/局部斜率、所有置换子集、权重、条件标签和输入/脚本SHA。CSV及PNG用于阅读；数值求值精度不充当DFT物理误差界。

源数据入口：[Kirsch2025论文](https://doi.org/10.1088/2515-7655/ada639)、[作者原始NEB数据](https://doi.org/10.5281/zenodo.14065754)、[Moon2016](https://doi.org/10.1016/j.jpowsour.2016.07.092)、[Moon官方Fig4](https://ars.els-cdn.com/content/image/1-s2.0-S0378775316309673-gr4.jpg)、[标记输运的主方程/变分理论背景](https://arxiv.org/abs/1805.11618)。本轮实际使用前次已下载原始文件，不以无法取得的SI或没有的Ea原始表填空。
'''
(H/'LiSi_Ea独立数据同模型重新对照与差异归因_20261113.md').write_text(report,encoding='utf-8')
print(json.dumps(status,ensure_ascii=False));print('report_bytes',len(report.encode('utf-8')))
