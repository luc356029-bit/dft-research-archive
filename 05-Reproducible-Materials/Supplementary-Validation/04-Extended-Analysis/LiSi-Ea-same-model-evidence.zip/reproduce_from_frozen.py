"""Portable offline reproduction from supplied fixed graph and case inputs."""
from pathlib import Path
import json,hashlib
import numpy as np
from exact_tracer import tracer_diffusion
H=Path(__file__).resolve().parent;target=H/'offline_reproduction.json'
if target.exists():raise FileExistsError('Use a fresh copy, or preserve the previous reproduction file under a new name.')
f=json.loads((H/'kinetic_inputs.json').read_text());a=json.loads((H/'Ea_recomparison_results.json').read_text());kb=8.617333262145e-5
Ts=np.array(a['original_weight_T']);w=np.array(a['original_weight_values']);X=np.c_[np.ones(4),1/Ts]
rows=[]
for name,c in a['cases'].items():
 E=np.array([np.inf if e is None else e for e in c['barriers_eV']]);ds=[]
 for T in Ts:
  rates=f['nu_s']*np.exp(-E/(kb*T));r=tracer_diffusion(f['neighbor'],f['integer_image'],rates[np.array(f['path_id'])],cell=f['cell_A'])
  D=r['D_scalar']*1e-16;ds.append(D)
  old=next(q['DLi_cm2_s'] for q in c['rows'] if q['T_K']==T)
  assert abs(D/old-1)<1e-10
 beta=np.linalg.solve(X.T@(w[:,None]*X),X.T@(w*np.log(ds)));ea=-kb*beta[1]
 assert abs(ea-c['Ea_250_400_fixed_weights']['Ea_eV'])<1e-10
 rows.append({'case':name,'DLi_cm2_s':ds,'Ea_eV':ea,'matched_original_output':True})
target.write_text(json.dumps({'frozen_input_sha256':hashlib.sha256((H/'kinetic_inputs.json').read_bytes()).hexdigest(),'rows':rows,'all_matched':True},indent=2));print('All six cases reproduced from frozen graph; no original project files required.')
