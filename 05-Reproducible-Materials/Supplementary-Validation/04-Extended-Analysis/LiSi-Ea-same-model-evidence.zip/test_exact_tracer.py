"""Analytic calibrations for a new evaluator of the existing KMC marginal."""
import unittest
import numpy as np
from exact_tracer import tracer_diffusion

class ExactTracerTests(unittest.TestCase):
    def ring(self,n=5,k=3.):
        neighbor=np.array([[(i+1)%n,(i-1)%n] for i in range(n)])
        jump=np.tile(np.array([[1.,0,0],[-1.,0,0]])[None,:,:],(n,1,1))
        return neighbor,jump,np.full((n,2),k)
    def test_single_file_ring_exact_long_time_tagged_diffusion(self):
        for n in [2,3,5,8]:
            a,g,k=self.ring(n)
            d=tracer_diffusion(a,g,k)['D_tensor']
            self.assertAlmostEqual(d[0,0],3./(n-1)**2,places=11)
            self.assertLess(abs(d[1:]).max(),1e-13)
    def test_bounded_coordinate_gauge_does_not_change_diffusion(self):
        a,g,k=self.ring();pos=np.arange(5.)[:,None]*np.array([[1,0,0]])
        # Vacancy vector gauge: add the change of bounded internal position.
        newg=g-(pos[a]-pos[:,None,:])
        x=tracer_diffusion(a,g,k)['D_tensor'];y=tracer_diffusion(a,newg,k)['D_tensor']
        np.testing.assert_allclose(x,y,atol=1e-12)
    def test_common_rate_rescaling_is_exact(self):
        a,g,k=self.ring();x=tracer_diffusion(a,g,k)['D_tensor'];y=tracer_diffusion(a,g,.4*k)['D_tensor']
        np.testing.assert_allclose(y,.4*x,rtol=1e-12,atol=1e-13)
    def test_zero_displacement_has_zero_diffusion(self):
        a,g,k=self.ring();x=tracer_diffusion(a,0*g,k)['D_tensor'];np.testing.assert_allclose(x,0.,atol=1e-14)

if __name__=='__main__':unittest.main()
