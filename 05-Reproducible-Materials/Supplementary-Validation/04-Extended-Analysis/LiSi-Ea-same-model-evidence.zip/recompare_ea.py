"""External barrier inputs -> same fixed-vacancy Li-tracer model and Ea definition."""
from pathlib import Path
import sys,json,hashlib,itertools,math,time,shutil,platform
import numpy as np
from ase.io import read
from ase import Atoms
from exact_tracer import tracer_diffusion
H=Path(__file__).resolve().parent;R=H.parents[1];EXT=R/'supplements/20261109_external_validation';t0=time.perf_counter()
sys.path.insert(0,str(R/'scripts'))
from network_arrays import supercell_arrays
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources={}
def bind(p):
 p=Path(p);sources[str(p)]=sha(p);return p
def load(p):return json.loads(bind(p).read_text(encoding='utf-8-sig'))
model=load(R/'analysis/transport_phase34_20261015/transport_model.json')
base=load(R/'analysis/transport_phase34_20261015/KMC_ext_00.json')
old=load(R/'supplements/20261112_key_attribution/P2_ea_sensitivity_v2.json')
lit=load(EXT/'root/barrier_controls_results.json');mapping=load(EXT/'modern/literature_orbit_mapping.json')
parent=read(bind(R/'analysis/host_symmetry_projection/POSCAR'))
for n in ['network_arrays.py','tracer_kmc.py','transport.py']:bind(R/'scripts'/n)
for n in ['IOP2025.pdf','2025_paths_li1si1.zip']:bind(EXT/'modern'/n)
for n in ['Moon2016_gr2.jpg','Moon2016_gr4.jpg','Moon2016_gr8_lrg.jpg','Moon_thesis.txt']:bind(EXT/'older'/n)
mp=base['network_mapping'];idx=np.array(mp['basis_indices']);img=np.array(mp['primitive_images']);cell=np.array(mp['supercell_matrix'])@parent.cell.array
sc=Atoms(numbers=parent.numbers[idx],positions=(parent.get_scaled_positions()[idx]+img)@parent.cell.array,cell=cell,pbc=True)
own=np.array(model['families']['Efr']['barriers_sym_eV']);kb=8.617333262145e-5;nu=model['attempt_frequency_s']
arr=supercell_arrays(parent,sc,mp,model['orbits'],nu*np.exp(-own/(kb*300)))
assert np.array_equal(arr['neighbor'],base['supplied_neighbor'])
assert np.max(abs(arr['displacement']-base['supplied_displacement_A']))<1e-10
assert np.max(abs(cell-np.array(base['cell_A'])))<1e-7
assert arr['neighbor'].shape==(32,6)
external=own.copy()
for entry in lit['literature_raw_barriers'].values():external[entry['own_orbit']]=entry['barrier_sym_eV']
# Verify raw energy conversion rather than relying on the old summary only.
raw_kirsch={}
for route,e in lit['literature_raw_barriers'].items():
 p=EXT/'modern/2025_paths_li1si1/li1si1'/f'li1si1_li_vac_path_{route}_def_energy.txt'
 values=np.loadtxt(bind(p));ener=values[:,-1] if values.ndim>1 else values
 barrier=float((max(ener)-(ener[0]+ener[-1])/2)*27.211386245988)
 assert abs(barrier-e['barrier_sym_eV'])<1e-9
 raw_kirsch[route]={'path_id':e['own_orbit'],'barrier_eV':barrier,'raw_source':str(p),'raw_sha256':sha(p)}

frozen={'neighbor':arr['neighbor'].tolist(),'integer_image':arr['integer_image'].tolist(),'displacement_A':arr['displacement'].tolist(),'path_id':arr['path_id'].tolist(),'cell_A':cell.tolist(),'host_slots':arr['host_slots'].tolist(),'own_barriers_eV':own.tolist(),'Kirsch_mapped_barriers_eV':[float(x) if i<3 else None for i,x in enumerate(external)],'nu_s':nu,'site_count':32,'Li_count':31,'cv':1/32}
(H/'kinetic_inputs.json').write_text(json.dumps(frozen,indent=2))
T0=np.array([r['T_K'] for r in old['rows']]);sy=np.array([r['SE']/r['D'] for r in old['rows']]);w=1/sy**2
cache={};results={};calibration=[]
def evaluate(E,T,nu_rel=None):
 E=np.array([np.inf if x is None else x for x in E]);nu_rel=np.ones(4) if nu_rel is None else np.asarray(nu_rel)
 key=(tuple(E),float(T),tuple(nu_rel))
 if key in cache:return cache[key]
 rates=nu*nu_rel*np.exp(-E/(kb*T))
 x=tracer_diffusion(arr['neighbor'],arr['integer_image'],rates[arr['path_id']],cell=cell,path_id=arr['path_id'])
 sensitivities=x['path_lograte_sensitivities']
 local=float(sum(s*e for s,e in zip(sensitivities,E) if np.isfinite(e)))
 row={'T_K':float(T),'DLi_cm2_s':x['D_scalar']*1e-16,'tensor_cm2_s':(x['D_tensor']*1e-16).tolist(),'tensor_eigenvalues_cm2_s':(x['tensor_eigenvalues']*1e-16).tolist(),'local_Li_Ea_eV':local,'path_lograte_sensitivities':sensitivities.tolist(),'relative_residual':x['relative_residual'],'states':x['states']}
 cache[key]=row;return row
def fit(rows,Ts=T0,weights=None):
 yy=np.log([next(r['DLi_cm2_s'] for r in rows if r['T_K']==temp) for temp in Ts]);X=np.c_[np.ones(len(Ts)),1/np.array(Ts)]
 ww=np.ones(len(Ts)) if weights is None else weights
 beta=np.linalg.solve(X.T@(ww[:,None]*X),X.T@(ww*yy))
 return {'temperatures_K':list(map(float,Ts)),'Ea_eV':float(-kb*beta[1]),'log_D0':float(beta[0]),'log_residuals':(yy-X@beta).tolist(),'weights':'OLS' if weights is None else 'same frozen marginal-error weights of original Li KMC, reused for all cases'}

cases={'own4':own.tolist(),'own3':[*own[:3],None],'Kirsch3':[*external[:3],None],'Kirsch3_plus_own03_BRIDGE':external.tolist(),'Moon_mapping_A_CANDIDATE':[.2725,.2519,.2348,.4658],'Moon_mapping_B_CANDIDATE':[.2725,.2348,.2519,.4658]}
for name,E in cases.items():
 rr=[evaluate(E,T) for T in [250,300,350,400,500,600,700,800]]
 results[name]={'barriers_eV':E,'rows':rr,'Ea_250_400_fixed_weights':fit(rr,weights=w),'Ea_250_400_OLS':fit(rr),'Ea_300_700_OLS':fit(rr,[300,400,500,600,700]),'source_status':'own finite model' if name.startswith('own') else 'strictly mapped independent NEB inputs on common 3-path graph' if name=='Kirsch3' else 'mixed-input bridge, not independent external benchmark' if name.startswith('Kirsch') else 'conditional color/orbit assignments, not admitted strict mapping'}
 print(name,results[name]['Ea_250_400_fixed_weights']['Ea_eV'],results[name]['Ea_300_700_OLS']['Ea_eV'],flush=True)

for r in old['rows']:
 q=evaluate(own,r['T_K']);calibration.append({'T_K':r['T_K'],'D_exact_cm2_s':q['DLi_cm2_s'],'D_existing_KMC_cm2_s':r['D'],'existing_KMC_SE':r['SE'],'difference_in_existing_SE':(q['DLi_cm2_s']-r['D'])/r['SE']})
# The channel-response weighted barrier must equal a direct slope.
local_checks=[]
for name in ['own4','own3','Kirsch3']:
 E=cases[name];beta=1/(kb*300);h=1e-3
 ea=-(math.log(evaluate(E,1/(kb*(beta+h)))['DLi_cm2_s'])-math.log(evaluate(E,1/(kb*(beta-h)))['DLi_cm2_s']))/(2*h)
 local_checks.append({'case':name,'local_from_response_eV':evaluate(E,300)['local_Li_Ea_eV'],'local_finite_difference_eV':ea,'absolute_difference_eV':abs(ea-evaluate(E,300)['local_Li_Ea_eV'])})
 assert local_checks[-1]['absolute_difference_eV']<1e-7

# Exact finite-change attribution with all orders, no linear additivity claim.
subset={}
for mask in range(8):
 E=[*own[:3],None]
 for j in range(3):
  if mask&(1<<j):E[j]=float(external[j])
 subset[mask]=fit([evaluate(E,T) for T in T0],weights=w)['Ea_eV']
shapley=[]
for j in range(3):
 value=0.
 for mask in range(8):
  if mask&(1<<j):continue
  n=mask.bit_count();value+=math.factorial(n)*math.factorial(2-n)/math.factorial(3)*(subset[mask|(1<<j)]-subset[mask])
 shapley.append(value)
assert abs(sum(shapley)-(subset[7]-subset[0]))<1e-12

# Missing external fourth barrier: sensitivity, never a pure external result.
fourth=[]
for e in [.4,float(own[3]),.4658,.5]:
 rr=[evaluate([*external[:3],e],T) for T in T0]
 fourth.append({'assumed_external_missing_E03_eV':e,'Ea_fixed_weights_eV':fit(rr,weights=w)['Ea_eV'],'status':'hypothesis-only missing-path control'})
prefactor=[]
for ratios in itertools.product([1.,2.],repeat=3):
 rr=[evaluate(cases['Kirsch3'],T,[*ratios,1.]) for T in T0]
 prefactor.append({'relative_nu_00_01_02':ratios,'Ea_fixed_weights_eV':fit(rr,weights=w)['Ea_eV'],'status':'factor-two relative-frequency sensitivity, not measured prefactors'})

out={'date':'2026-11-13','scope':'Independent NEB barrier inputs re-evaluated in exactly the same finite fixed-vacancy Li tracer model; no DFT/MD/KMC trajectory or production change','main_quantity':'Li tracer scalar trace(D)/3; fixed cv=1/32; 250,300,350,400 K slope -kB*dlnD/d(1/T)','nu_assumption_s':nu,'original_KMC_Ea_fixed_weights_eV':old['fit_variants'][0]['Ea_eV'],'cases':results,'existing_KMC_calibration':calibration,'analytic_local_slope_checks':local_checks,'three_path_exact_subsets_Ea':subset,'Shapley_Kirsch_minus_own_eV':shapley,'missing03_hypothesis_controls':fourth,'path_specific_prefactor_hypotheses':prefactor,'raw_Kirsch_barriers':raw_kirsch,'original_weight_T':T0.tolist(),'original_weight_values':w.tolist(),'source_sha256':sources,'evaluator_sha256':sha(H/'exact_tracer.py'),'analyzer_sha256':sha(__file__),'runtime_seconds':time.perf_counter()-t0,'python':platform.python_version(),'numpy':np.__version__,'limits':['Independent microscopic inputs, not an independently observed macroscopic Ea','All external barriers transplanted into common finite graph and common assumed prefactors','Kirsch does not supply external path03; main comparison removes it on both sides','Moon mapping/prefactors remain conditional','No intrinsic concentration or formation-energy correction attempted']}
(H/'Ea_recomparison_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('CALIBRATION',calibration);print('SHAPLEY',shapley,'SECONDS',out['runtime_seconds'],flush=True)
