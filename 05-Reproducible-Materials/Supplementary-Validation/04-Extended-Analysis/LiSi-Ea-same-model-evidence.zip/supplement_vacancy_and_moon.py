"""Keep vacancy local Ea separate; explain conditional Moon barrier-only contrasts."""
from pathlib import Path
import sys,json,itertools,math,hashlib,time
import numpy as np
from ase.io import read
H=Path(__file__).resolve().parent;R=H.parents[1];sys.path.insert(0,str(R/'scripts'))
from network_arrays import primitive_edges
from transport import periodic_diffusion
from exact_tracer import tracer_diffusion
main=json.loads((H/'Ea_recomparison_results.json').read_text());inputs=json.loads((H/'kinetic_inputs.json').read_text())
model=json.loads((R/'analysis/transport_phase34_20261015/transport_model.json').read_text())
parent=read(R/'analysis/host_symmetry_projection/POSCAR');kb=8.617333262145e-5;nu=inputs['nu_s'];T=np.array(main['original_weight_T']);weights=np.array(main['original_weight_values'])
def fit(logd):
 X=np.c_[np.ones(4),1/T];beta=np.linalg.solve(X.T@(weights[:,None]*X),X.T@(weights*np.array(logd)))
 return float(-kb*beta[1])
def vacancy(E,temp):
 E=np.array([np.inf if x is None else x for x in E]);rates=nu*np.exp(-E/(kb*temp))
 D,_=periodic_diffusion(8,primitive_edges(parent,model['orbits'],rates));cart=parent.cell.array.T@D@parent.cell.array
 return float(np.trace(cart)/3*1e-16)
vac=[];beta=1/(kb*300);h=1e-3
for name in ['own4','own3','Kirsch3','Kirsch3_plus_own03_BRIDGE']:
 E=main['cases'][name]['barriers_eV'];ds=[vacancy(E,temp) for temp in T]
 local=-(math.log(vacancy(E,1/(kb*(beta+h))))-math.log(vacancy(E,1/(kb*(beta-h)))))/(2*h)
 vac.append({'case':name,'Dvac300_cm2_s':ds[1],'local_vacancy_Ea300_eV':local,'finite_range_vacancy_Ea250_400_eV':fit(np.log(ds))})
known=next(r for r in model['families']['Efr']['temperature_rows'] if r['T_K']==300)
assert abs(vac[0]['Dvac300_cm2_s']/known['Dvac_scalar_cm2_s']-1)<1e-10
own=np.array(inputs['own_barriers_eV']);neighbor=np.array(inputs['neighbor']);image=np.array(inputs['integer_image']);pid=np.array(inputs['path_id']);cell=np.array(inputs['cell_A'])
def getEa(E):
 dd=[]
 for temp in T:
  rates=nu*np.exp(-np.array(E)/(kb*temp));r=tracer_diffusion(neighbor,image,rates[pid],cell=cell,path_id=pid);dd.append(math.log(r['D_scalar']*1e-16))
 return fit(dd)
moon=[]
for label in ['Moon_mapping_A_CANDIDATE','Moon_mapping_B_CANDIDATE']:
 target=np.array(main['cases'][label]['barriers_eV']);values={}
 for mask in range(16):
  E=np.where([(mask&(1<<i))!=0 for i in range(4)],target,own);values[mask]=getEa(E)
 sh=[]
 for i in range(4):
  total=0.
  for mask in range(16):
   if mask&(1<<i):continue
   n=mask.bit_count();total+=math.factorial(n)*math.factorial(3-n)/math.factorial(4)*(values[mask|(1<<i)]-values[mask])
  sh.append(total)
 assert abs(sum(sh)-(values[15]-values[0]))<1e-12
 moon.append({'label':label,'delta_Ea_versus_own4_eV':values[15]-values[0],'Shapley_path_00_01_02_03_eV':sh,'all_16_input_subsets_Ea_eV':values})
out={'date':'2026-11-13','vacancy_quantities_do_not_replace_Li_tracer_Ea':vac,'Moon_conditional_barrier_attribution':moon,'warning':'Moon orbit hypotheses and common prefactor remain assumptions. This does not reproduce the reported 0.306eV or prove its error.','source_sha256':{str(H/n):hashlib.sha256((H/n).read_bytes()).hexdigest() for n in ['Ea_recomparison_results.json','kinetic_inputs.json','exact_tracer.py']},'analyzer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
vac_subsets={}
external=main['cases']['Kirsch3']['barriers_eV']
for mask in range(8):
 E=[*own[:3],None]
 for j in range(3):
  if mask&(1<<j):E[j]=external[j]
 local=-(math.log(vacancy(E,1/(kb*(beta+h))))-math.log(vacancy(E,1/(kb*(beta-h)))))/(2*h)
 vac_subsets[mask]=local
vv=[]
for i in range(3):
 value=0.
 for mask in range(8):
  if mask&(1<<i):continue
  n=mask.bit_count();value+=math.factorial(n)*math.factorial(2-n)/6*(vac_subsets[mask|(1<<i)]-vac_subsets[mask])
 vv.append(value)
out['vacancy_local300_Kirsch_input_Shapley_eV']=vv
out['vacancy_local300_all_subsets_eV']=vac_subsets
(H/'vacancy_and_Moon_attribution.json').write_text(json.dumps(out,indent=2));print(json.dumps({'vacancy':vac,'moon':[{k:r[k] for k in ['label','delta_Ea_versus_own4_eV','Shapley_path_00_01_02_03_eV']} for r in moon]},indent=2))
