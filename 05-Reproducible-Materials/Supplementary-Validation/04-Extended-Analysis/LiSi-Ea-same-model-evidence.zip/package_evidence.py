"""Recheck source/script association and package this isolated evidence directory."""
from pathlib import Path
import hashlib, json, math, zipfile

H = Path(__file__).resolve().parent
def read(name): return json.loads((H / name).read_text(encoding='utf-8'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def source_path(s):
    if s.startswith('/mnt/c/'): return Path('C:/' + s[7:])
    return Path(s)

a = read('Ea_recomparison_results.json')
b = read('vacancy_and_Moon_attribution.json')
checks = []
for label, obj in [('main', a), ('supplement', b)]:
    for name, expected in obj['source_sha256'].items():
        p = source_path(name)
        assert p.is_file(), name
        assert sha(p) == expected, name
        checks.append({'scope': label, 'source': str(p), 'sha256': expected, 'ok': True})
for name, expected in [
    ('exact_tracer.py', a['evaluator_sha256']),
    ('recompare_ea.py', a['analyzer_sha256']),
    ('supplement_vacancy_and_moon.py', b['analyzer_sha256']),
]:
    assert sha(H / name) == expected, name
    checks.append({'scope': 'analyzer', 'source': name, 'sha256': expected, 'ok': True})

assert read('source_integrity.json')['all_passed']
assert read('offline_reproduction.json')['all_matched']
assert len(read('offline_reproduction.json')['rows']) == 6
assert all(r['matched_original_output'] for r in read('offline_reproduction.json')['rows'])
test_log = (H / 'tests_green.log').read_text(encoding='utf-8')
assert 'Ran 4 tests' in test_log and 'OK' in test_log
for case in a['cases'].values():
    for r in case['rows']:
        assert math.isfinite(r['DLi_cm2_s']) and r['DLi_cm2_s'] > 0
        assert min(r['tensor_eigenvalues_cm2_s']) > 0
        assert r['relative_residual'] < 1e-9
assert max(abs(x['difference_in_existing_SE']) for x in a['existing_KMC_calibration']) < 0.536
assert max(x['absolute_difference_eV'] for x in a['analytic_local_slope_checks']) < 1e-10
assert abs(sum(a['Shapley_Kirsch_minus_own_eV']) - (
    a['three_path_exact_subsets_Ea']['7'] - a['three_path_exact_subsets_Ea']['0'])) < 1e-12
assert abs(sum(b['vacancy_local300_Kirsch_input_Shapley_eV']) - (
    b['vacancy_local300_all_subsets_eV']['7'] - b['vacancy_local300_all_subsets_eV']['0'])) < 1e-12
for r in b['Moon_conditional_barrier_attribution']:
    assert abs(sum(r['Shapley_path_00_01_02_03_eV']) - r['delta_Ea_versus_own4_eV']) < 1e-12
verification = {
    'date': '2026-11-13', 'source_and_script_checks': checks,
    'math_and_portable_reproduction': 'passed', 'all_passed': True,
    'no_new_DFT_MD_HPC_or_production_changes': True,
    'scope': 'Artifact association and same-model numerical evidence, not a physical accuracy certificate',
}
(H / 'evidence_verification.json').write_text(json.dumps(verification, ensure_ascii=False, indent=2), encoding='utf-8')
excluded = {'MANIFEST.json', 'delivery_receipt.json', 'package_receipt.json'}
files = sorted(p for p in H.rglob('*') if p.is_file() and p.name not in excluded
               and p.suffix != '.zip' and '__pycache__' not in p.parts)
manifest = {
    'date': '2026-11-13', 'files': [
        {'path': p.relative_to(H).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in files
    ],
    'self_hash_excluded': True,
    'source_scope': 'Original microscopic inputs plus isolated code, outputs, logs, and frozen portable graph',
}
(H / 'MANIFEST.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
bundle = H / 'LiSi_Ea_same_model_evidence_20261113.zip'
assert not bundle.exists(), 'Preserve the previous immutable bundle; do not overwrite'
with zipfile.ZipFile(bundle, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for p in files + [H / 'MANIFEST.json']:
        z.write(p, p.relative_to(H).as_posix())
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None
    for row in manifest['files']:
        assert hashlib.sha256(z.read(row['path'])).hexdigest() == row['sha256']
receipt = {'date': '2026-11-13', 'file_count_in_zip': len(files) + 1,
           'zip': bundle.name, 'bytes': bundle.stat().st_size, 'sha256': sha(bundle),
           'CRC_and_internal_SHA_passed': True, 'source_and_script_check_count': len(checks)}
(H / 'package_receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(receipt, ensure_ascii=False, indent=2))
