"""Record the actual local numerical environment; no scientific calculation."""
from pathlib import Path
import importlib.metadata as metadata
import json, platform, sys

target = Path(__file__).resolve().parent / 'environment_versions.json'
data = {
    'python': sys.version,
    'platform': platform.platform(),
    'packages': {name: metadata.version(name) for name in ['numpy', 'scipy', 'matplotlib', 'ase', 'mpmath']},
    'core_offline_requirements': ['numpy', 'scipy'],
    'scope': 'Actual inference-independent numerical environment; no DFT/MD/HPC execution',
}
target.write_text(json.dumps(data, indent=2), encoding='utf-8')
print(json.dumps(data, indent=2))
