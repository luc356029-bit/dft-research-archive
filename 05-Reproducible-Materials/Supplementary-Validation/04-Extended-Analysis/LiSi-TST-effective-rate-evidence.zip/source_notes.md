# 来源、证据等级与本轮范围

- Voter，《Introduction to the Kinetic Monte Carlo Method》，作者章节PDF，§4–6：https://www.fml.t.u-tokyo.ac.jp/~izumi/CMS/MC/Introduction_kMC.pdf 。本轮网页工具成功读取，定位到指数驻留、平衡通量、再穿越和谐近似部分；只用作一般方法，未把固体常见适用性移植为LiSi误差保证。
- Vineyard1957，DOI https://doi.org/10.1016/0022-3697(57)90059-8 ，出版社摘要可读，说明多体谐频率比；未声称读到完整付费全文或本LiSi路径频率。
- Di Gesù等2016，《Jump Markov models and transition state theory: the quasi-stationary distribution approach》，https://arxiv.org/abs/1605.02643 ，本轮成功读取作者PDF，关于亚稳状态/准稳态投影与指数退出；不用其一般定理证明LiSi800K自动满足条件。
- Chandler1978 DOI https://doi.org/10.1063/1.436049 本轮网页工具读取失败；不当已读全文依据，无需重复下载。已有Voter反应通量/再穿越论述足以支持本轮限定。
- 模型/代码与已有钟审查为原始项目证据；不是论文明确给出的条件。ν=10¹³为本项目假设；独立热态有效速率仍未知。
- 本轮未开展新的高召回文献搜索、失败SI重试、势推断或DFT/MD/KMC轨迹。不修改旧报告/生产代码，新报告补充“漏时”一词的准确解释。
- 延续用户既有同步要求，用Google Drive文件管理技能将本报告与小证据包保存到既有codex/DFT复刻；不覆盖其他报告，不改变分享权限。
