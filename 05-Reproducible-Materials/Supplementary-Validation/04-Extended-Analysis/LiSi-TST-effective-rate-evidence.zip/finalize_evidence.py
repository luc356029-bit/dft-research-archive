"""Verify unchanged sources and make a small immutable evidence archive."""
from pathlib import Path
import hashlib, json, zipfile

H=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=json.loads((H/'rate_evidence.json').read_text(encoding='utf-8'))
for source in r['source_sha256'].values():
    assert sha(Path(source['path']))==source['sha256'],source['path']
assert r['verified_source_facts']['common_nu_s']==1e13
assert r['physical_admission']['current_rates_verified_for_real_LiSi_800K'].startswith('UNVERIFIED')
assert not r['new_DFT_MD_ML_KMC_trajectories_or_HPC']
assert not r['production_files_changed']
assert not r['physical_admission']['extra_TP_time_should_be_added_now']
files=sorted(p for p in H.rglob('*') if p.is_file() and p.suffix!='.zip'
             and p.name not in ['MANIFEST.json','package_receipt.json','delivery_receipt.json']
             and '__pycache__' not in p.parts)
manifest={'date':'2026-11-13','files':[{'path':p.relative_to(H).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files],
          'scope':'Read-only source facts and conceptual clarification; no measured physical rate or transition time'}
(H/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
zpath=H/'LiSi_TST_effective_rate_evidence_20261113.zip'
assert not zpath.exists(),'Do not overwrite an existing evidence archive'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files+[H/'MANIFEST.json']:z.write(p,p.relative_to(H).as_posix())
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    for f in manifest['files']:
        assert hashlib.sha256(z.read(f['path'])).hexdigest()==f['sha256']
receipt={'date':'2026-11-13','zip':zpath.name,'bytes':zpath.stat().st_size,'sha256':sha(zpath),
         'file_count':len(files)+1,'source_SHA_and_ZIP_CRC_internal_SHA_passed':True}
(H/'package_receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
