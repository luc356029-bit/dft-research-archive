"""Read existing model/code and audit evidence; no new dynamics or rate changes."""
from pathlib import Path
import hashlib, json, math, shutil

H = Path(__file__).resolve().parent
R = H.parents[1]
paths = {
    'rate_code': R/'scripts/transport.py',
    'clock_code': R/'scripts/tracer_kmc.py',
    'production_model': R/'analysis/transport_phase34_20261015/transport_model.json',
    'old_clock_audit': R/'supplements/20261112_clock_transition_audit/clock_audit.json',
    'ML_verdict': R/'supplements/20261113_ml_dynamics_validation/screen_verdict.json',
    'Ea_verdict': R/'supplements/20261113_Ea_external_recomparison/Ea_validation_status.json',
}
source = {k: {'path': str(p), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in paths.items()}
m = json.loads(paths['production_model'].read_text(encoding='utf-8'))
c = json.loads(paths['old_clock_audit'].read_text(encoding='utf-8'))
t = next(r for r in c['temperature_rows'] if r['T_K'] == 800)
assert m['attempt_frequency_s'] == 1e13
assert m['frequency_origin'] == 'Assumed common constant, not calculated Vineyard frequencies'
assert 'frequency_s*np.exp(-barriers/(KB_EV*temperature_K))' in paths['rate_code'].read_text(encoding='utf-8')
assert 'time+=-np.log(max(v,np.finfo(float).tiny))/total[old]' in paths['clock_code'].read_text(encoding='utf-8')
assert math.isclose(sum(k*n for k,n in zip(t['channel_rates_s'],t['channels_per_family'])),t['total_exit_rate_s'],rel_tol=1e-14)
assert math.isclose(1e12/t['total_exit_rate_s'],t['mean_holding_ps'],rel_tol=1e-14)
out = {
    'date': '2026-11-13', 'source_sha256': source,
    'verified_source_facts': {
        'formula': 'k_model = assumed_common_nu * exp(-Em_NEB/kBT)',
        'common_nu_s': m['attempt_frequency_s'],
        'frequency_origin': m['frequency_origin'],
        'holding_clock': '-ln(U)/sum_outgoing_rates',
        'independent_flight_segment_integrated': False,
        'path_specific_Vineyard_prefactors_computed': False,
        'physical_dynamic_transmission_coefficients_computed': False,
        '800K_reused_model_values': t,
    },
    'physical_admission': {
        'TST_formula_equivalent_to_missing_all_transition_time': False,
        'correct_effective_rates_may_absorb_elapsed_time': 'conditional on state and event definition and Markov coarse graining',
        'current_rates_verified_for_real_LiSi_800K': 'UNVERIFIED, not demonstrated wrong',
        'extra_TP_time_should_be_added_now': False,
        'production_rates_should_be_changed_now': False,
        'close_Ea_validates_absolute_rates': False,
        'TST_flux_rate_is_not_a_transition_path_duration': True,
    },
    'new_DFT_MD_ML_KMC_trajectories_or_HPC': False,
    'production_files_changed': False,
}
(H/'rate_evidence.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
S = H/'source_snapshots'; S.mkdir(exist_ok=True)
for key in ['rate_code','clock_code','production_model','old_clock_audit','Ea_verdict']:
    shutil.copyfile(paths[key], S/(key + paths[key].suffix))
print('Read-only audit passed: six sources bound by SHA; model clock/rate arithmetic confirmed, physical effective rates remain unverified.')
