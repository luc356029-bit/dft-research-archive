"""Rebuild archived LiSi graph, verify old KMC blocks, run mapped Em without Path03."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import platform
import sys
import time
from pathlib import Path, PurePosixPath
from zipfile import ZipFile

import numpy as np

ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT / "LiSi_evidence.zip"
OUT = ROOT / "lisi_path03_control"
OUT.mkdir(exist_ok=True)
z = ZipFile(ARCHIVE)

def get(name, contains=None):
    members = [s for s in z.namelist() if PurePosixPath(s).name == name and (contains is None or contains in s)]
    if len(members) != 1:
        raise RuntimeError((name, contains, members))
    return z.read(members[0])

inputs = {
    "model": get("transport_model.json"),
    "base": get("conv128_800.json"),
    "controls": get("barrier_controls_results.json"),
    "disable03": get("P1_disable03_raw.json"),
    "poscar": get("POSCAR", "host_symmetry_projection"),
    "tracer_kmc": get("tracer_kmc.py"),
}
model = json.loads(inputs["model"])
base = json.loads(inputs["base"])
controls = json.loads(inputs["controls"])
previous = json.loads(inputs["disable03"])
original_script = OUT / "tracer_kmc_original.py"
original_script.write_bytes(inputs["tracer_kmc"])
spec = importlib.util.spec_from_file_location("tracer_kmc_original", original_script)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

# Rebuild the same periodic graph as network_arrays.supercell_arrays without
# relying on ASE. The archive's mapping and explicit orbit members fix the graph.
lines = inputs["poscar"].decode().splitlines()
cell = np.array([[float(x) for x in lines[i].split()] for i in range(2, 5)])
frac = np.array([[float(x) for x in lines[i].split()] for i in range(8, 24)])
mapping = base["mapping"]
P = np.array(mapping["supercell_matrix"])
idx = np.array(mapping["basis_indices"])
images = np.array(mapping["primitive_images"])
inverse = np.linalg.inv(P)
sf = ((frac[idx] + images) @ inverse) % 1
assert np.max(np.abs(P @ cell - np.array(base["cell_A"]))) < 1e-7
li = np.flatnonzero(idx < 8)
assert len(li) == 128
local = {int(host): i for i, host in enumerate(li)}
rows = [[] for _ in li]
for orbit in model["orbits"]:
    pid = orbit["path_id"]
    for i, j, *S in orbit["members"]:
        S = np.array(S, dtype=int)
        vec = (frac[j] + S - frac[i]) @ cell
        for h in li[idx[li] == i]:
            destination = (frac[j] + S + images[h]) @ inverse
            candidates = li[idx[li] == j]
            delta = destination - sf[candidates]
            errors = np.max(np.abs(delta - np.rint(delta)), axis=1)
            selected = np.flatnonzero(errors < 1e-7)
            if len(selected) != 1:
                raise ValueError("Periodic graph match is not unique")
            h2 = int(candidates[selected[0]])
            image = np.rint(destination - sf[h2]).astype(int)
            a, b = local[int(h)], local[h2]
            rows[a].append((b, vec, pid, image))
            rows[b].append((a, -vec, pid, -image))
rows = [sorted(r, key=lambda e: (e[2], e[0], *e[3])) for r in rows]
assert set(map(len, rows)) == {6}
neighbor = np.array([[e[0] for e in r] for r in rows])
displacement = np.array([[e[1] for e in r] for r in rows])
path_id = np.array([[e[2] for e in r] for r in rows])
assert neighbor.shape == (128, 6)
assert np.all(neighbor != np.arange(128)[:, None])

T = 800.0
kb = 8.617333262145e-5
nu = model["attempt_frequency_s"]
own = np.array(model["families"]["Efr"]["barriers_sym_eV"])
modern = own.copy()
for item in controls["literature_raw_barriers"].values():
    modern[item["own_orbit"]] = item["barrier_sym_eV"]
assert np.allclose(modern, controls["modern_three_plus_ours_fourth_eV"], atol=1e-12)

def rates(energies, disable=False):
    rr = nu * np.exp(-energies / (kb * T))
    if disable:
        rr[3] = 0
    return rr[path_id]

def verify_old(expected, energies, disable, seed):
    actual = mod.simulate(neighbor, displacement, rates(energies, disable), 200_000, 4, seed)
    for key in ["block_Dtracer_A2_s", "block_Dvacancy_A2_s", "block_time_s"]:
        np.testing.assert_allclose(actual[key], expected[key][:4], rtol=5e-11, atol=0)
    return {key: float(np.max(np.abs(np.array(actual[key]) / np.array(expected[key][:4]) - 1))) for key in ["block_Dtracer_A2_s", "block_Dvacancy_A2_s", "block_time_s"]}

checks = {
    "original_em_no03_seed137": verify_old(previous["raw_KMC"][0], own, True, 137),
    "mapped_em_with03_seed2027": verify_old(controls["Li_tracer_KMC_control"]["raw_KMC"][0], modern, False, 2027),
}
print("Archive graph and first four blocks reproduced:", json.dumps(checks), flush=True)

tic = time.perf_counter()
rr = rates(modern, disable=True)
runs = []
for seed in [137, 991]:
    t0 = time.perf_counter()
    result = mod.simulate(neighbor, displacement, rr, 4_000_000, 80, seed)
    runs.append(result)
    print("Completed seed", seed, "in", round(time.perf_counter() - t0, 1), "s", flush=True)

def pool(rs, key):
    d = np.concatenate([r[key] for r in rs])
    t = np.concatenate([r["block_time_s"] for r in rs])
    z = d * t
    leave = (z.sum() - z) / (t.sum() - t)
    return {"D_cm2_s": float(z.sum() / t.sum() * 1e-16), "SE_cm2_s": float(np.sqrt((len(t)-1) / len(t) * ((leave - leave.mean())**2).sum()) * 1e-16), "blocks": len(t)}

pooled = pool(runs, "block_Dtracer_A2_s")
vacancy = pool(runs, "block_Dvacancy_A2_s")
on = controls["Li_tracer_KMC_control"]["DLi"]
off = previous["DLi"]
onratio = pooled["D_cm2_s"] / on["D_cm2_s"]
onratio_se = onratio * np.hypot(pooled["SE_cm2_s"]/pooled["D_cm2_s"], on["SE_cm2_s"]/on["D_cm2_s"])
counts = np.sum([r["event_counts_by_directed_edge"] for r in runs], axis=0)
uncov = int(np.sum((rr > 0) & (counts == 0)))
out = {
    "scope": "Li tracer, 800 K, mapped Kirsch Em 00/01/02, Path03 disabled, same archived finite model and assumed nu; not a reconstruction of AIMD",
    "seeds": [137, 991],
    "events_per_seed": 4000000,
    "blocks_per_seed": 80,
    "burn_events_per_seed": 20000,
    "barriers_ours_eV": own.tolist(),
    "barriers_mapped_eV": modern.tolist(),
    "nu_s": nu,
    "verification": checks,
    "DLi": pooled,
    "Dvac": vacancy,
    "mapped_with03": on,
    "own_without03": off,
    "mapped_off_over_on": float(onratio),
    "mapped_off_over_on_independent_SE": float(onratio_se),
    "unsampled_positive_edges": uncov,
    "runtime_seconds": time.perf_counter()-tic,
    "python": platform.python_version(),
    "numpy": np.__version__,
    "archive_sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
    "inputs_sha256": {k: hashlib.sha256(v).hexdigest() for k, v in inputs.items()},
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "raw_KMC": runs,
}
(OUT / "mapped_three_no03.json").write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({k: out[k] for k in ["DLi", "Dvac", "mapped_with03", "own_without03", "mapped_off_over_on", "mapped_off_over_on_independent_SE", "unsampled_positive_edges", "runtime_seconds"]}, indent=2), flush=True)
