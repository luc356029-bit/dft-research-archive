# 2026-11-13范围收缩：来源与访问边界

使用Google Drive文件管理技能在原目录更新既有Markdown主文件与状态，保留ID；按当前请求沿用简明中文证据分级。不新建Google Doc，不修改共享权限。旧完整方案只作历史，当前以本目录收缩方案为准。

本轮仅窄范围查现成Li–Si势及官方权重说明；没有重做D/Ea高召回检索或Kirsch失败SI下载。ænet站点超时、旧UU文件链接404、GitHub目录网页读取受限均不重试；改用作者仓库公开Git tree/blob元数据及Materials Cloud记录API。没有下载大训练集、权重或运行下载的代码。

此前Qaisrani全文经网页验证页/403而未读全，本次通过正式Europe PMC公开全文XML API成功读取；新增确认其无缺陷Li12Si7/Li13Si4及CP2K/BLYP-D3相域。旧记录的访问受阻仍属历史，现不能再写为“相域未知”。没有访问受保护SI或绕过验证页。

来源绑定：public_source_receipt.json保存6个官方/作者文档响应的URL、时刻、字节SHA；aenet_document_receipt.json另存精确blob文档读取记录。sources/aenet_tinker_tree.json只列文件元数据，仓库tree SHA与模型blob SHA1不冒充已下载权重的SHA256。candidate_ledger.json列具体候选与资格缺口。

既有数据：existing_evidence/完整复制前轮清单、历史计时、前轮一致性检查及CPU32验收报告。清单中的原始路径和SHA保留；本轮只对实际用于判断的报告/脚本及少量计时原件做完整性核对，不冒称重新验收全部原始DFT。

所有“未来20–50步／1–2小时”仅为最小数值/计时门槛和预算护栏，不是MD性能实测、轨迹采样承诺或执行授权；没有实际τTP、κ或新的D结果。检查结果只支持文档与证据一致性，不支持动力学物理通过。
