"""Read public model documentation/metadata only. Never import or run any model."""
from pathlib import Path
import datetime, hashlib, json, urllib.request, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'sources'
OUT.mkdir(exist_ok=True)
SOURCES = [
    ('qaisrani2026.xml', 'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC13255252/fullTextXML'),
    ('aenet_tinker_tree.json', 'https://api.github.com/repos/atomisticnet/aenet-tinker/git/trees/master?recursive=1'),
    ('aenet_tinker_README.rst', 'https://raw.githubusercontent.com/atomisticnet/aenet-tinker/master/README.rst'),
    ('materialscloud_record.json', 'https://archive.materialscloud.org/api/records/67p3q-dch39'),
    ('mace_README.md', 'https://raw.githubusercontent.com/ACEsuit/mace/main/README.md'),
    ('mace_foundations_models.py.txt', 'https://raw.githubusercontent.com/ACEsuit/mace/main/mace/calculators/foundations_models.py'),
]
entries = []
for name, url in SOURCES:
    target = OUT / name
    if target.exists():
        raise RuntimeError(f'Refusing to overwrite source: {target}')
    entry = {'url': url, 'retrieved_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'LiSi-documentation-audit/1.0'})
        with urllib.request.urlopen(req, timeout=20) as response:
            content = response.read(4_000_001)
            if len(content) > 4_000_000:
                raise ValueError('Documentation response exceeds bounded download')
            entry['final_url'] = response.url
        target.write_bytes(content)
        entry.update(file=str(target.relative_to(ROOT)), bytes=len(content), sha256=hashlib.sha256(content).hexdigest(), status='retrieved')
    except Exception as exc:
        entry.update(status='unavailable', error=str(exc))
    entries.append(entry)

record = {'date': '2026-11-13', 'operation': 'public documentation and file metadata GET only; no weights downloaded or executed', 'entries': entries}
(ROOT/'public_source_receipt.json').write_text(json.dumps(record,ensure_ascii=False,indent=2), encoding='utf-8')
print(json.dumps(record,ensure_ascii=False,indent=2))

if (OUT/'qaisrani2026.xml').exists():
    tree=ET.fromstring((OUT/'qaisrani2026.xml').read_bytes())
    paragraphs=[]
    for n in tree.iter():
        if n.tag in ['p','sec']:
            s=' '.join(''.join(n.itertext()).split())
            if len(s)<6000 and (('Li12Si7' in s and 'Li13Si4' in s) or ('will be made' in s and ('available' in s))):
                paragraphs.append(s)
    (ROOT/'qaisrani_relevant_paragraphs.json').write_text(json.dumps(paragraphs,ensure_ascii=False,indent=2),encoding='utf-8')
    print('QAISRANI_RELEVANT',json.dumps(paragraphs,ensure_ascii=False)[:10000])
if (OUT/'aenet_tinker_tree.json').exists():
    tree=json.loads((OUT/'aenet_tinker_tree.json').read_text(encoding='utf-8'))
    selected=[n for n in tree.get('tree',[]) if any(w in n['path'].lower() for w in ['potential','.nn','.ann','lith','lisi','license'])]
    print('AENET_TREE_SHA',tree.get('sha'),'TRUNCATED',tree.get('truncated'))
    print('AENET_CANDIDATE_FILES',json.dumps(selected,ensure_ascii=False)[:11000])
