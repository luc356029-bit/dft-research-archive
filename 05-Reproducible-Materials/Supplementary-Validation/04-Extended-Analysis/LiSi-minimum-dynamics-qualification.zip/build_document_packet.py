"""Assemble a documentation-only screen and check source/file integrity; no physics."""
from pathlib import Path
import hashlib, json, shutil, zipfile

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'20261113_transition_time_plan'
REPORT='LiSi四路径_合格ML势与最小动力学预检_收缩方案_20261113.md'
sha=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,value):
    (ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

tree=json.loads((ROOT/'sources/aenet_tinker_tree.json').read_text(encoding='utf-8'))
weight_paths=['examples/01-ANN-MD-aLiSi/ANN-fit/Li.15t-15t.nn-04153','examples/01-ANN-MD-aLiSi/ANN-fit/Si.15t-15t.nn-04153']
weights=[n for n in tree['tree'] if n['path'] in weight_paths]
assert len(weights)==2 and tree['truncated'] is False
save('candidate_ledger.json', {
 'date':'2026-11-13','scope':'Existing publicly documented potentials only; no inference, training, force calculation or MD',
 'qualified_for_direct_use_on_all_four_paths':False,
 'absence_of_qualification_is_not_proof_no_suitable_model_exists':True,
 'candidates':[
  {'name':'aenet LiSi ANN, example fit 04153', 'priority':'first existing-label screening candidate',
   'status':'WEIGHTS_LISTED_TARGET_QUALIFICATION_NOT_ESTABLISHED',
   'repository':'https://github.com/atomisticnet/aenet-tinker', 'repository_tree_sha1':tree['sha'],
   'weight_metadata_only_not_downloaded':weights,
   'dataset':'https://archive.materialscloud.org/records/67p3q-dch39',
   'reference':'VASP PBE/PAW 520 eV; multiple compositions and perturbed crystals in broader mainly-amorphous corpus',
   'missing':['Exact I41/a Li31Si32 four-path validation','PAW and k-grid binding','800 K off-MEP force validation'],
   'license_scope':'Repository LICENSE archived; exact weight-use terms must be retained/checked before actual reuse; code license alone is not asserted to settle all data rights'},
  {'name':'MACE-MATPES-PBE-0', 'status':'PUBLIC_CHECKPOINT_TARGET_QUALIFICATION_NOT_ESTABLISHED',
   'model_url':'https://github.com/ACEsuit/mace-foundations/releases/download/mace_matpes_0/MACE-matpes-pbe-omat-ft.model',
   'official_documentation':'https://github.com/ACEsuit/mace',
   'documented_reference':'MATPES-PBE, DFT PBE, no +U correction', 'documented_license':'ASL as listed by official model table; not assumed MIT',
   'fallback_family':'MACE-MP (MPTrj PBE+U); not independently screened here',
   'missing':['Current four-path energies and physical forces','Vacancy and thermal-saddle neighborhood coverage'],
   'weights_downloaded_or_executed':False},
  {'name':'Qaisrani et al. 2026 fine-tuned MACE', 'status':'PUBLISHED_TEST_DOMAIN_DOES_NOT_MATCH_DIRECT_REUSE',
   'doi':'10.1021/acs.jctc.5c02035', 'fulltext_api':'https://www.ebi.ac.uk/europepmc/webservices/rest/PMC13255252/fullTextXML',
   'published_test_phases':['defect-free Li12Si7','defect-free Li13Si4'],
   'published_reference':'CP2K BLYP-D3, GTH, DZVP-MOLOPT-SR-GTH; 500 K reference trajectories',
   'weight_repository_identified':False,
   'availability_statement':'Article promises future public repository, but gives no concrete deposited model link in that statement',
   'not_inferred':['A globally unavailable model','Transferable validation for LiSi single vacancy','Measured transition time for any project path']}
 ]})

evidence=ROOT/'existing_evidence'
evidence.mkdir(exist_ok=True)
for name in ['existing_evidence_inventory.json','raw_timing_evidence.json','plan_verification.json']:
    shutil.copyfile(OLD/name,evidence/name)
shutil.copyfile(ROOT.parents[1]/'analysis/CPU32_acceptance_phase36_20261015.json',evidence/'CPU32_acceptance_phase36_20261015.json')
save('screen_status.json',{
 'date':'2026-11-13','status':'DOCUMENT_SCREEN_COMPLETE_NO_NEW_PHYSICAL_CALCULATION',
 'active_scope':['Existing ML potential eligibility','Existing DFT sufficiency and minimal-pilot cost boundary'],
 'removed_from_active_scope':['Four full Hessians','Preset 1000–4000 trajectories/path','Large-scale ML training','New semi-Markov model','Complex propagators and multistate models'],
 'qualified_existing_ML_potential_confirmed':False,'candidate_weights_metadata_identified':True,
 'existing_DFT_supports_static_qualification_and_one_path_numerical_pilot':True,
 'measured_warm_MD_cost_available':False,'actual_transition_times_available':False,
 'performed':['Read existing evidence','Read public model documentation and weight file metadata','Document revision, integrity check and Drive synchronization'],
 'not_performed':['Model inference or installation','Weights download','New DFT/MD/Hessian/local fitting/KMC','Training','SSH/HPC/scheduler or balance query'],
 'production_code_changed':False,'NEB_barriers_changed':False,'KMC_rates_changed':False,
 'future_small_pilot_steps_are_not_committed_sampling':True,
 'future_CPU32_job_cap_core_hours':[32,64], 'cap_is_not_MD_cost_estimate':True,
 'next_action':'Stop after documentation delivery. Any future inference or one-path cost pilot requires a new execution instruction.',
 'superseded_drive_main_id':'1T5i2851r5TYrsGUt4Xq-nP91faaKhBK6'})

oldmain=OLD/'LiSi四路径_迁移时间与动力学修正_计算方案待验收_20261113.md'
save('revision_record.json',{
 'date':'2026-11-13','reason':'User narrowed active scope; no new calculation authorized',
 'prior_report':str(oldmain),'prior_report_sha256':sha(oldmain),
 'prior_status':str(OLD/'plan_status.json'),'prior_status_sha256':sha(OLD/'plan_status.json'),
 'prior_package_drive_id':'1jIVYkWBjTm0sOGMrEYrVEd2-HIEqs9c5',
 'prior_package_sha256':'06fdd38ecc067ca20ac4b4e941412bce2f9c1b5193dd7f3cc652f45896d061b3',
 'history_policy':'Prior local full plan and old immutable ZIP retained only as history. Active Drive report/status replaced in place; current project index points here.',
 'active_report':REPORT,'active_report_sha256':sha(ROOT/REPORT)})

notes='''# 2026-11-13范围收缩：来源与访问边界

使用Google Drive文件管理技能在原目录更新既有Markdown主文件与状态，保留ID；按当前请求沿用简明中文证据分级。不新建Google Doc，不修改共享权限。旧完整方案只作历史，当前以本目录收缩方案为准。

本轮仅窄范围查现成Li–Si势及官方权重说明；没有重做D/Ea高召回检索或Kirsch失败SI下载。ænet站点超时、旧UU文件链接404、GitHub目录网页读取受限均不重试；改用作者仓库公开Git tree/blob元数据及Materials Cloud记录API。没有下载大训练集、权重或运行下载的代码。

此前Qaisrani全文经网页验证页/403而未读全，本次通过正式Europe PMC公开全文XML API成功读取；新增确认其无缺陷Li12Si7/Li13Si4及CP2K/BLYP-D3相域。旧记录的访问受阻仍属历史，现不能再写为“相域未知”。没有访问受保护SI或绕过验证页。

来源绑定：public_source_receipt.json保存6个官方/作者文档响应的URL、时刻、字节SHA；aenet_document_receipt.json另存精确blob文档读取记录。sources/aenet_tinker_tree.json只列文件元数据，仓库tree SHA与模型blob SHA1不冒充已下载权重的SHA256。candidate_ledger.json列具体候选与资格缺口。

既有数据：existing_evidence/完整复制前轮清单、历史计时、前轮一致性检查及CPU32验收报告。清单中的原始路径和SHA保留；本轮只对实际用于判断的报告/脚本及少量计时原件做完整性核对，不冒称重新验收全部原始DFT。

所有“未来20–50步／1–2小时”仅为最小数值/计时门槛和预算护栏，不是MD性能实测、轨迹采样承诺或执行授权；没有实际τTP、κ或新的D结果。检查结果只支持文档与证据一致性，不支持动力学物理通过。
'''
(ROOT/'source_notes.md').write_text(notes,encoding='utf-8')

checks=[]
previous=json.loads((evidence/'plan_verification.json').read_text(encoding='utf-8'))
prod={}
for path,expected in previous['production_sha256'].items():
    actual=sha(path); prod[path]=actual
    checks.append({'name':'unchanged production '+Path(path).name,'passed':actual==expected})
oldinv=json.loads((evidence/'existing_evidence_inventory.json').read_text(encoding='utf-8'))
for path,expected in oldinv['source_sha256'].items():
    checks.append({'name':'unchanged existing source '+path,'passed':sha(path)==expected})
timing=json.loads((evidence/'raw_timing_evidence.json').read_text(encoding='utf-8'))
for label,data in timing['files'].items():
    checks.append({'name':'unchanged raw timing '+label,'passed':sha(data['path'])==data['sha256']})
for entry in json.loads((ROOT/'public_source_receipt.json').read_text(encoding='utf-8'))['entries']:
    checks.append({'name':'source response '+entry['url'],'passed':entry['status']=='retrieved' and sha(ROOT/entry['file'])==entry['sha256']})
assert all(c['passed'] for c in checks)
save('document_integrity.json',{'date':'2026-11-13','checks':checks,'all_passed':True,'production_sha256':prod,'assembler_sha256':sha(__file__),'warning':'File/source integrity only; no model, rate, dynamics or physical validation was run'})

files=[p for p in ROOT.rglob('*') if p.is_file() and p.suffix!='.zip' and p.name not in ['MANIFEST.json','delivery_receipt.json','package_receipt.json']]
manifest={'date':'2026-11-13','kind':'documentation-only narrowed scope','entries':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]}
save('MANIFEST.json',manifest)
bundle=ROOT/'LiSi_最小动力学资格筛查_20261113.zip'
with zipfile.ZipFile(bundle,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in files+[ROOT/'MANIFEST.json']: z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None
    for n in manifest['entries']: assert hashlib.sha256(z.read(n['path'])).hexdigest()==n['sha256']
save('package_receipt.json',{'date':'2026-11-13','zip':bundle.name,'bytes':bundle.stat().st_size,'sha256':sha(bundle),'files_including_manifest':len(files)+1,'all_manifest_hashes_and_zip_crc_verified':True})
print(json.dumps({'file_checks':len(checks),'all_passed':True,'report_bytes':(ROOT/REPORT).stat().st_size,'package':json.loads((ROOT/'package_receipt.json').read_text(encoding='utf-8'))},ensure_ascii=False))
