"""Verify this read-only audit, plot conditional sensitivity and package new evidence."""
from pathlib import Path
import csv,hashlib,json,zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];PROJECT=ROOT.parents[1]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=json.loads((HERE/'clock_audit.json').read_text(encoding='utf-8'));checks=[]
def check(name,result):
    checks.append(dict(name=name,passed=bool(result)));assert result,name
check('analysis source unchanged',sha(d['analyzer_path'])==d['analyzer_sha256'])
for p,digest in d['source_sha256'].items():check('input SHA '+str(Path(p).relative_to(PROJECT)),sha(p)==digest)
check('existing mean clock agrees with1/R',abs(d['old_800K_clock']['relative_difference_from_inverse_total_rate'])<.001)
for row in d['temperature_rows']:check('alpha04 inverse clock '+str(row['T_K']),abs(row['mean_holding_ps_with_common_frequency_times_04']/row['mean_holding_ps']-2.5)<1e-12)
check('all local XDATCAR have saved input association',sum(d['local_trajectory_inventory']['IBRION_input_counts'].values())==d['local_trajectory_inventory']['count']==134)
check('no found800K MD input',set(d['local_trajectory_inventory']['IBRION_input_counts'])=={'-1','2','3'})
check('no production simulation run',not any(d[k] for k in ['production_change','new_DFT','new_MD','new_KMC']))
rows=d['toy_extra_time_scenarios'];check('zero extra time has CTMC alpha scaling',rows[0]['D04_over_D1_with_fixed_extra_time']==.4)
check('increasing hypothetical time reduces D',np.all(np.diff([r['D_over_jump_clock_asymptotic'] for r in rows])<0))
R=d['temperature_rows'][-1]['total_exit_rate_s'];tau=np.linspace(0,1.6,200)*1e-12
fig,ax=plt.subplots(figsize=(8.1,4.1),layout='constrained')
ax.plot(tau*1e12,1/(1+R*tau),label='Extra-time D / original CTMC D')
ax.plot(tau*1e12,.4*(1+R*tau)/(1+.4*R*tau),label='nu x0.4: D ratio with fixed extra time')
ax.axhline(.4,linestyle='--',color='gray',label='CTMC-only frequency scaling: 0.4')
ax.set(xlabel='Assumed extra time per event (ps)',ylabel='Diffusion-coefficient ratio',ylim=(0,1.05),title='Serial-time illustration; not a LiSi duration estimate')
ax.grid(alpha=.2);ax.legend(fontsize=9);fig.savefig(HERE/'conditional_time_sensitivity.png',dpi=180)
with (HERE/'conditional_time_sensitivity.csv').open('w',encoding='utf-8-sig',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
verification=dict(date='2026-11-12',status='READ_ONLY_CLOCK_AUDIT_VERIFIED_PHYSICAL_800K_VALIDITY_UNRESOLVED',
    checks=checks,actual_LiSi_transition_time_measured=False,clock_audit_sha256=sha(HERE/'clock_audit.json'),
    production_code_sha256=sha(ROOT/'scripts/tracer_kmc.py'),analyzer_path=str(Path(__file__)),analyzer_sha256=sha(__file__),
    scope='Source dependencies, already saved blocks and algebraic conditional-time analysis only; no full workflow/DFT revalidation')
p=HERE/'clock_verification.json'
if p.exists():raise FileExistsError(p)
p.write_text(json.dumps(verification,ensure_ascii=False,indent=2),encoding='utf-8')
ownfiles=[p for p in HERE.iterdir() if p.is_file() and p.suffix!='.zip' and p.name not in ['MANIFEST.json','delivery_receipt.json']]
inputs=[Path(p) for p in d['source_sha256'] if Path(p).suffix.lower()!='.pdf']
manifest=dict(date='2026-11-12',outputs={p.name:dict(size=p.stat().st_size,sha256=sha(p)) for p in ownfiles},
    included_inputs={str(p.relative_to(PROJECT)):dict(size=p.stat().st_size,sha256=sha(p)) for p in inputs},
    other_source_SHA={p:v for p,v in d['source_sha256'].items() if Path(p).suffix.lower()=='.pdf'},
    previous_source_bundle='https://drive.google.com/file/d/1BUbOThH_foPL0uuB65wD0Xy1AE_b9_PD/view',
    note='Existing source PDFs stay in earlier complete packet; this supplement includes no new primary PDF or MD trajectory. No licensed potentials or credentials included.')
(HERE/'MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
archive=HERE/'LiSi_时钟与有限迁移时间_分析脚本证据_20261112.zip'
if archive.exists():raise FileExistsError(archive)
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in [*ownfiles,HERE/'MANIFEST.json',*inputs]:z.write(p,'project/'+p.relative_to(PROJECT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for p in [*ownfiles,HERE/'MANIFEST.json',*inputs]:assert hashlib.sha256(z.read('project/'+p.relative_to(PROJECT).as_posix())).hexdigest()==sha(p)
print(json.dumps(dict(status=verification['status'],checks=len(checks),all_checks_passed=all(r['passed'] for r in checks),archive=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),ensure_ascii=False,indent=2))
