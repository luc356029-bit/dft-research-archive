"""No new simulation: inspect current clock, existing timing and toy dead-time limits."""
from pathlib import Path
import ast,collections,hashlib,json,re,platform
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];PROJECT=ROOT.parents[1]
sources={}
def bind(p):
    p=Path(p);sources[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest();return p
def load(p):return json.loads(bind(p).read_text(encoding='utf-8'))
script=bind(ROOT/'scripts/tracer_kmc.py');text=script.read_text(encoding='utf-8');tree=ast.parse(text)
time_updates=[n for n in ast.walk(tree) if isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Name) and n.target.id=='time']
assert len(time_updates)==1
clock_expression=ast.get_source_segment(text,time_updates[0]);assert 'total[old]' in clock_expression and 'np.log' in clock_expression
model=load(ROOT/'analysis/transport_phase34_20261015/transport_model.json')
base=load(ROOT/'supplements/20261109_external_validation/root/conv128_800.json')
freq=load(ROOT/'supplements/20261112_key_attribution/P1_external_prefactors.json')
bind(ROOT/'scripts/transport.py');bind(ROOT/'scripts/network_arrays.py')
bind(ROOT/'supplements/20261109_kumar_comparison/Kumar2020_author.pdf')
bind(ROOT/'supplements/20261109_external_validation/modern/ACS2022_SI.pdf')
bind(ROOT/'supplements/20261109_external_validation/modern/IOP2025.pdf')
bind(ROOT/'supplements/20261109_external_validation/modern/literature_orbit_mapping.json')
E=np.array(model['families']['Efr']['barriers_sym_eV']);g=np.array([2*o['Ni']/8 for o in model['orbits']]);kb=8.617333262145e-5;nu=model['attempt_frequency_s']
rows=[]
for T in [250.,300.,400.,800.]:
    k=nu*np.exp(-E/(kb*T));R=float(g@k)
    rows.append(dict(T_K=T,Em_over_kBT=(E/(kb*T)).tolist(),channel_rates_s=k.tolist(),channels_per_family=g.tolist(),total_exit_rate_s=R,
        mean_holding_ps=1e12/R,mean_holding_ps_with_common_frequency_times_04=1e12/(.4*R)))
R=rows[-1]['total_exit_rate_s'];w=1/R
rawtime=sum(sum(r['block_time_s']) for r in base['raw_KMC']);N=sum(r['nevents'] for r in base['raw_KMC']);mean=rawtime/N
assert abs(mean/w-1)<.001
assert g.tolist()==[1,2,1,2]
assert base['attempt_frequency_s']==nu and base['T_K']==800
clockrecord=dict(path=str(script),line=time_updates[0].lineno,expression=clock_expression,
    interpretation='Exponential CTMC holding time; no separate transition-flight interval or velocities.',
    warning='Not proved to equal physical vibration-only waiting. Correct coarse-grained rates may already include elapsed physical time; appending a flight time without state/rate definitions can double count.')
toy=[]
for tau_ps in [0.,.02,.05,.1,.2,.5,1.]:
    tau=tau_ps*1e-12;factor=1/(1+R*tau);emp=rawtime/(rawtime+N*tau)
    ratio=.4*(1+R*tau)/(1+.4*R*tau)
    toy.append(dict(assumed_extra_time_per_event_ps=tau_ps,D_over_jump_clock_asymptotic=factor,D_over_jump_clock_existing_blocks=emp,
        D04_over_D1_with_fixed_extra_time=ratio,
        model='Conditional serial renewal illustration: same embedded spatial walk/branching/correlations; nonoverlapping extra time not already represented by rates. Not a proposed physical correction.'))
required=(base['DLi']['D_cm2_s']/1e-7-1)/R
thresholds={str(epsilon):dict(max_tau_ps=(epsilon/(1-epsilon))/R*1e12,
    definition='Ensures omitted-time relative reduction <= epsilon in this toy model only, not full KMC accuracy') for epsilon in [.05,.1]}

# Audit all local exported trajectory names against nearest saved INCAR.
# Record input scope explicitly; no claim to revalidate SCF or all actual parameters.
basepath=(PROJECT/'hpc/results').resolve();trajectories=[]
for p in basepath.rglob('XDATCAR'):
    incar=None
    for ancestor in [p.parent,*p.parent.parents]:
        if not ancestor.is_relative_to(basepath):break
        if (ancestor/'INCAR').is_file():incar=ancestor/'INCAR';break
    params={}
    if incar:
        s=bind(incar).read_text(encoding='utf-8',errors='replace');s='\n'.join(re.split(r'[!#]',ln)[0] for ln in s.splitlines())
        for key in ['IBRION','POTIM','NSW','IMAGES','IOPT','TEBEG','SMASS']:
            vals=re.findall(r'\b'+key+r'\s*=\s*([^;\n]+)',s,re.I)
            if vals:params[key]=vals[-1].strip()
    trajectories.append(dict(path=str(p),bytes=p.stat().st_size,nearest_INCAR=str(incar) if incar else None,parameters=params,
        admissible_as_800K_AIMD=False if params.get('IBRION') in ['-1','2','3'] else None))
counts=dict(collections.Counter(r['parameters'].get('IBRION','unknown') for r in trajectories))
assert counts.get('0',0)==0
out=dict(date='2026-11-12',status='CLOCK_IMPLEMENTATION_CONFIRMED_800K_PHYSICAL_TIME_SEPARATION_UNVALIDATED',
    code_clock=clockrecord,temperature_rows=rows,old_800K_clock=dict(events=N,physical_seconds=rawtime,mean_ps_per_event=mean*1e12,relative_difference_from_inverse_total_rate=mean/w-1,
        mean_event_interval_for_one_Li_population_average_ps=(base['N_Li']*w*1e12),warning='Population-averaged Li interval must not replace local vacancy escape time in a time-scale-separation test.'),
    toy_extra_time_scenarios=toy,omission_tolerance_thresholds=thresholds,
    full_2677_ratio_explanation_by_toy=dict(required_mean_extra_time_ps=required*1e12,extra_over_holding=required/w,transition_fraction_of_total=required/(w+required),
        interpretation='Would require transition time comparable to/larger than model holding time, incompatible with a strongly separated rare-event justification; not a measured duration and not proof of actual cause.'),
    local_trajectory_inventory=dict(count=len(trajectories),IBRION_input_counts=counts,records=trajectories,scope='Saved INCAR association, not repeated full output validation. All found files classified as static/optimization, not 800K production MD.'),
    frequency_sensitivity_scope='D(alpha*k)=alpha*D(k) is exact only for the unchanged CTMC generator/time-rescaled paths; it is not an unconditional identity for atomistic AIMD.',
    unresolved=['LiSi800K transition-path-time distribution for explicitly defined A/B cores','Intrabasin dephasing/relaxation time and a Markov/rate plateau','Dynamical transmission coefficient kappa and correlated multi-jump events'],
    production_change=False,new_DFT=False,new_MD=False,new_KMC=False,source_sha256=sources,
    analyzer_path=str(Path(__file__)),analyzer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),environment=dict(python=platform.python_version(),numpy=np.__version__))
p=HERE/'clock_audit.json'
if p.exists():raise FileExistsError(p)
p.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:out[k] for k in ['status','code_clock','temperature_rows','old_800K_clock','toy_extra_time_scenarios','omission_tolerance_thresholds','full_2677_ratio_explanation_by_toy']},ensure_ascii=False,indent=2))
print('trajectory inventory',len(trajectories),counts)
