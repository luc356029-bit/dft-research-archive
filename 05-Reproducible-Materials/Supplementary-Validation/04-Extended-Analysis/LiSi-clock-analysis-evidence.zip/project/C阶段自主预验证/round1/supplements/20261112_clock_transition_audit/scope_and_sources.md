# 2026-11-12：等待时钟、有限迁移时间与800 K近似审查

执行用户指定的五项问题。只读生产代码、已有KMC分块、NEB/文献元数据和本地输出类型，做解析敏感性分析；不新增DFT/AIMD/KMC，不将t_transition设为1/ν，不重复SI下载或高召回检索。

新外部检索只针对TST/驻留时间/transition-path time方法及LiSi是否有已发表迁移耗时，优先第一手来源。以下是本轮核对来源，不是重新核验此前所有文献：

1. A. F. Voter, Introduction to the Kinetic Monte Carlo Method。作者预印本24页，§3–5的失忆/指数驻留时钟、§6的TST与动态修正；正式章节2007年。预印本封面仍写2005 in press，日期不混用。
   - https://www.fml.t.u-tokyo.ac.jp/~izumi/CMS/MC/Introduction_kMC.pdf
   - 正式来源元数据：https://laro.lanl.gov/esploro/outputs/conferenceProceeding/INTRODUCTION-TO-THE-KINETIC-MONTE-CARLO/9916364647803761
2. E. Vanden-Eijnden & F. A. Tal, JCP123,184103(2005), DOI10.1063/1.2102898。此次核对PubMed所载作者摘要，支持分割面穿越率与亚稳态间真实速率需要区分、κ动态修正。没有冒称已读未取得的全文。
   - https://pubmed.ncbi.nlm.nih.gov/16292895/
3. W. K. Kim & R. R. Netz, JCP143,224108(2015), DOI10.1063/1.4936408，作者预印本arXiv1509.00418。摘要明确区分transition path和first-passage path，并说明需自由能景观与位置依赖扩散率。这是方法证据，不是LiSi迁移耗时。
   - https://arxiv.org/abs/1509.00418
4. VASP官方IBRION说明：0是MD；2是共轭梯度优化；3列为结构优化用阻尼动力学，不能把优化轨迹当800 K真实动力学。
   - https://vasp.at/wiki/index.php/IBRION ，本次读取页面版本oldid37190。
5. 复用Kumar2020原始PDF（本地已有）：p3 Eq4/6，p11再穿越因子讨论，p17 AppendixB。p11所在段为bulk-Si讨论，不冒充LiSi实测κ；LiSi频率图没有提供动态κ或transition-path时间。
6. 复用Kirsch2022既有SI：FigS7是其他硅化锂相连续跳跃之间的时间间隔，不是目标LiSi的单次过渡路径耗时。复用Kirsch2025已取得主文/公开NEB数据；无实际MD轨迹，不重试SI。

访问失败保留：2016年Analytic dynamical corrections to transition state theory (DOI10.1088/1367-2630/18/1/013023) 的DOI全文入口被robots拒绝；不作为已读全文、不继续尝试同入口。初始搜索结果的摘要仅作候选，不据此提取本材料耗时。

目标LiSi的三项窄查询（LiSi+transition time、Kirsch+silicides+duration、LiSi+recrossing）没有取得可定量使用的实际迁移时长；这是本轮有限检索结果，不是证明学术界不存在此数据。
